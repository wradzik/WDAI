/*functionality for changing target _blank to same */
/* sorry, didn't have time*/